import { createContext, useContext, ReactNode, useState, useEffect } from 'react';
import { 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  deleteDoc, 
  query, 
  orderBy,
  writeBatch
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './lib/firebase';
import { Note, FinanceRecord, MissedPrayer, DailyDoc, SpecialNote, Budget, SavingGoal, TripSummary, TripTemplate, RoutineActivity, RoutineCompletion } from './types';
import { INITIAL_MISSED_PRAYERS, INITIAL_IG_NOTES } from './data';
import { useAuth } from './components/AuthWrapper';

interface AppState {
  notes: Note[];
  financeRecords: FinanceRecord[];
  missedPrayers: MissedPrayer[];
  docs: DailyDoc[];
  specials: SpecialNote[];
  budgets: Budget[];
  savings: SavingGoal[];
  trips: TripSummary[];
  tripTemplates: TripTemplate[];
  activities: RoutineActivity[];
  completions: RoutineCompletion[];
  loading: boolean;
  confirmDialog: { isOpen: boolean; message: string; onConfirm: () => void; isDestructive?: boolean; confirmText?: string } | null;
  alertMessage: string | null;
  financeMappings: { [key: string]: string[] };
  financeCategoryPrefs: { [key: string]: { iconName: string; color: string } };
  hideAmounts: boolean;
  darkMode: boolean;
  soundEnabled: boolean;
  setDarkMode: (dark: boolean) => void;
  setSoundEnabled: (enabled: boolean) => void;
  setHideAmounts: (hide: boolean) => void;
  setAlert: (message: string | null) => void;
  showConfirm: (message: string, onConfirm: () => void, isDestructive?: boolean, confirmText?: string) => void;
  closeConfirm: () => void;
  updateFinanceMapping: (group: string, categories: string[]) => void;
  deleteFinanceMapping: (group: string) => void;
  updateCategoryPref: (category: string, pref: { iconName: string; color: string }) => void;
  addBudget: (budget: Budget) => void;
  deleteBudget: (id: string) => void;
  addSaving: (saving: SavingGoal) => void;
  updateSaving: (saving: SavingGoal) => void;
  deleteSaving: (id: string) => void;
  user: import('firebase/auth').User | null;
  addNote: (note: Note) => void;
  updateNote: (note: Note) => void;
  deleteNote: (id: string) => void;
  addTrip: (trip: TripSummary) => void;
  updateTrip: (trip: TripSummary) => void;
  deleteTrip: (id: string) => void;
  addTripTemplate: (template: TripTemplate) => void;
  deleteTripTemplate: (id: string) => void;
  addFinanceRecord: (record: FinanceRecord) => void;
  updateFinanceRecord: (record: FinanceRecord) => void;
  updateFinanceCategoryBulk: (oldCategory: string, newCategory: string) => void;
  deleteFinanceCategoryBulk: (category: string) => void;
  addFinanceRecordsBulk: (records: FinanceRecord[]) => void;
  deleteFinanceRecord: (id: string) => void;
  togglePrayer: (id: string) => void;
  addMissedPrayer: (prayer: MissedPrayer) => void;
  deleteMissedPrayer: (id: string) => void;
  deleteAllMissedPrayers: () => void;
  addDoc: (doc: DailyDoc) => void;
  addSpecial: (special: SpecialNote) => void;
  deleteSpecial: (id: string) => void;
  addActivity: (act: RoutineActivity) => void;
  deleteActivity: (id: string) => void;
  toggleCompletion: (activityId: string, dateStr: string) => void;
}

const AppContext = createContext<AppState | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [notes, setNotes] = useState<Note[]>([]);
  const [financeRecords, setFinanceRecords] = useState<FinanceRecord[]>([]);
  const [missedPrayers, setMissedPrayers] = useState<MissedPrayer[]>([]);
  const [docs, setDocs] = useState<DailyDoc[]>([]);
  const [specials, setSpecials] = useState<SpecialNote[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [savings, setSavings] = useState<SavingGoal[]>([]);
  const [activities, setActivities] = useState<RoutineActivity[]>([]);
  const [completions, setCompletions] = useState<RoutineCompletion[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmDialog, setConfirmDialog] = useState<{ isOpen: boolean; message: string; onConfirm: () => void; isDestructive?: boolean; confirmText?: string } | null>(null);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [financeMappings, setFinanceMappings] = useState<{ [key: string]: string[] }>({});
  const [financeCategoryPrefs, setFinanceCategoryPrefs] = useState<{ [key: string]: { iconName: string; color: string } }>({});
  const [hideAmounts, setHideAmounts] = useState(() => localStorage.getItem('fajmus-hide-amounts') === 'true');
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem('fajmus-dark-mode') === 'true');
  const [soundEnabled, setSoundEnabled] = useState(() => localStorage.getItem('fajmus-sound-enabled') !== 'false');

  const setAlert = (message: string | null) => {
    setAlertMessage(message);
    if (message) {
      setTimeout(() => {
        setAlertMessage((prev) => prev === message ? null : prev);
      }, 3000);
    }
  };
  const showConfirm = (message: string, onConfirm: () => void, isDestructive = true, confirmText = "Ya, Hapus") => {
    setConfirmDialog({ isOpen: true, message, onConfirm, isDestructive, confirmText });
  };
  const closeConfirm = () => {
    setConfirmDialog(null);
  };

  const toggleHideAmounts = (hide: boolean) => {
    setHideAmounts(hide);
    localStorage.setItem('fajmus-hide-amounts', hide ? 'true' : 'false');
  };

  const toggleDarkMode = (dark: boolean) => {
    setDarkMode(dark);
    localStorage.setItem('fajmus-dark-mode', dark ? 'true' : 'false');
    if (dark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const toggleSoundEnabled = (enabled: boolean) => {
    setSoundEnabled(enabled);
    localStorage.setItem('fajmus-sound-enabled', enabled ? 'true' : 'false');
  };

  // Sync dark mode on mount
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  // Track if initial data has loaded
  const [initialLoaded, setInitialLoaded] = useState({
    notes: false,
    finance: false,
    prayers: false,
    docs: false,
    specials: false,
    budgets: false,
    savings: false,
    trips: false,
    tripTemplates: false,
    activities: false,
    completions: false,
    mappings: false,
    categoryPrefs: false
  });

  const [trips, setTrips] = useState<TripSummary[]>([]);
  const [tripTemplates, setTripTemplates] = useState<TripTemplate[]>([]);

  // Sync with Firestore
  useEffect(() => {
    if (!user) {
      setNotes([]);
      setFinanceRecords([]);
      setMissedPrayers([]);
      setDocs([]);
      setTrips([]);
      setTripTemplates([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    const userPath = `users/${user.uid}`;
    
    // Listeners
    const unsubNotes = onSnapshot(query(collection(db, `${userPath}/notes`), orderBy('createdAt', 'desc')), (snapshot) => {
      setNotes(snapshot.docs.map(d => d.data() as Note));
      setInitialLoaded(prev => ({ ...prev, notes: true }));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `${userPath}/notes`));

    const unsubFinance = onSnapshot(query(collection(db, `${userPath}/finance`), orderBy('createdAt', 'desc')), (snapshot) => {
      setFinanceRecords(snapshot.docs.map(d => d.data() as FinanceRecord));
      setInitialLoaded(prev => ({ ...prev, finance: true }));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `${userPath}/finance`));

    const unsubPrayers = onSnapshot(collection(db, `${userPath}/prayers`), (snapshot) => {
      setMissedPrayers(snapshot.docs.map(d => d.data() as MissedPrayer));
      setInitialLoaded(prev => ({ ...prev, prayers: true }));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `${userPath}/prayers`));

    const unsubDocs = onSnapshot(query(collection(db, `${userPath}/docs`), orderBy('createdAt', 'desc')), (snapshot) => {
      setDocs(snapshot.docs.map(d => d.data() as DailyDoc));
      setInitialLoaded(prev => ({ ...prev, docs: true }));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `${userPath}/docs`));

    const unsubSpecials = onSnapshot(query(collection(db, `${userPath}/specials`), orderBy('createdAt', 'desc')), (snapshot) => {
      setSpecials(snapshot.docs.map(d => d.data() as SpecialNote));
      setInitialLoaded(prev => ({ ...prev, specials: true }));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `${userPath}/specials`));

    const unsubBudgets = onSnapshot(collection(db, `${userPath}/budgets`), (snapshot) => {
      setBudgets(snapshot.docs.map(d => d.data() as Budget));
      setInitialLoaded(prev => ({ ...prev, budgets: true }));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `${userPath}/budgets`));

    const unsubSavings = onSnapshot(collection(db, `${userPath}/savings`), (snapshot) => {
      setSavings(snapshot.docs.map(d => d.data() as SavingGoal));
      setInitialLoaded(prev => ({ ...prev, savings: true }));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `${userPath}/savings`));

    const unsubTrips = onSnapshot(collection(db, `${userPath}/trips`), (snapshot) => {
      setTrips(snapshot.docs.map(d => d.data() as TripSummary));
      setInitialLoaded(prev => ({ ...prev, trips: true }));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `${userPath}/trips`));

    const unsubTripTemplates = onSnapshot(collection(db, `${userPath}/tripTemplates`), (snapshot) => {
      setTripTemplates(snapshot.docs.map(d => d.data() as TripTemplate));
      setInitialLoaded(prev => ({ ...prev, tripTemplates: true }));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `${userPath}/tripTemplates`));
    
    const unsubActivities = onSnapshot(collection(db, `${userPath}/activities`), (snapshot) => {
      setActivities(snapshot.docs.map(d => d.data() as RoutineActivity));
      setInitialLoaded(prev => ({ ...prev, activities: true }));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `${userPath}/activities`));

    const unsubCompletions = onSnapshot(collection(db, `${userPath}/completions`), (snapshot) => {
      setCompletions(snapshot.docs.map(d => d.data() as RoutineCompletion));
      setInitialLoaded(prev => ({ ...prev, completions: true }));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `${userPath}/completions`));

    const unsubMappings = onSnapshot(doc(db, `${userPath}/settings/financeMappings`), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        // Convert old structure if exists, or just use as is if already new
        const mappedData: { [key: string]: string[] } = {};
        Object.entries(data).forEach(([k, v]) => {
          if (Array.isArray(v)) {
            mappedData[k] = v;
          } else {
             // Legacy migration: { category: group } -> { group: [category] }
             const group = v as string;
             if (!mappedData[group]) mappedData[group] = [];
             if (!mappedData[group].includes(k)) mappedData[group].push(k);
          }
        });
        setFinanceMappings(mappedData);
      }
      setInitialLoaded(prev => ({ ...prev, mappings: true }));
    }, (err) => handleFirestoreError(err, OperationType.GET, `${userPath}/settings/financeMappings`));

    const unsubCategoryPrefs = onSnapshot(doc(db, `${userPath}/settings/financeCategoryPrefs`), (snapshot) => {
      if (snapshot.exists()) {
        setFinanceCategoryPrefs(snapshot.data() as any);
      }
      setInitialLoaded(prev => ({ ...prev, categoryPrefs: true }));
    }, (err) => handleFirestoreError(err, OperationType.GET, `${userPath}/settings/financeCategoryPrefs`));

    return () => {
      unsubNotes();
      unsubFinance();
      unsubPrayers();
      unsubDocs();
      unsubSpecials();
      unsubBudgets();
      unsubSavings();
      unsubTrips();
      unsubTripTemplates();
      unsubActivities();
      unsubCompletions();
      unsubMappings();
      unsubCategoryPrefs();
    };
  }, [user]);

  // Update loading state when all initial data is loaded
  useEffect(() => {
    if (initialLoaded.notes && initialLoaded.finance && initialLoaded.prayers && initialLoaded.docs && initialLoaded.specials && initialLoaded.budgets && initialLoaded.savings && initialLoaded.trips && initialLoaded.tripTemplates && initialLoaded.activities && initialLoaded.completions && initialLoaded.mappings && initialLoaded.categoryPrefs) {
      setLoading(false);
    }
  }, [initialLoaded]);

  // Migration from LocalStorage to Firestore (one-time)
  useEffect(() => {
    if (!user || loading) return;

    const migrationFlag = localStorage.getItem(`fajmuls-migrated-${user.uid}`);
    if (migrationFlag) return;

    const checkAndMigrate = async () => {
      const userPath = `users/${user.uid}`;
      const suffix = `-${user.uid}`;
      const batch = writeBatch(db);
      let hasData = false;
      
      // Notes
      const localNotes = localStorage.getItem(`fajmuls-notes${suffix}`);
      if (localNotes) {
        const notesToMigrate = JSON.parse(localNotes);
        if (notesToMigrate.length > 0) {
          notesToMigrate.forEach((n: Note) => {
            batch.set(doc(db, `${userPath}/notes`, n.id), n);
          });
          hasData = true;
        }
      } else if (notes.length === 0) {
        // Only seed if both local and remote are empty
        INITIAL_IG_NOTES.forEach((n) => {
          batch.set(doc(db, `${userPath}/notes`, n.id), n);
        });
        hasData = true;
      }

      // Prayers
      const localPrayers = localStorage.getItem(`fajmuls-prayers${suffix}`);
      if (localPrayers) {
        const prayersToMigrate = JSON.parse(localPrayers);
        if (prayersToMigrate.length > 0) {
          prayersToMigrate.forEach((p: MissedPrayer) => {
            batch.set(doc(db, `${userPath}/prayers`, p.id), p);
          });
          hasData = true;
        }
      } else if (missedPrayers.length === 0) {
        INITIAL_MISSED_PRAYERS.forEach((p) => {
          batch.set(doc(db, `${userPath}/prayers`, p.id), p);
        });
        hasData = true;
      }

      // Finance
      const financeLocal = localStorage.getItem(`fajmuls-finance${suffix}`);
      if (financeLocal) {
        const data = JSON.parse(financeLocal);
        data.forEach((r: FinanceRecord) => {
          batch.set(doc(db, `${userPath}/finance`, r.id), r);
        });
        hasData = true;
      }

      // Docs
      const docsLocal = localStorage.getItem(`fajmuls-docs${suffix}`);
      if (docsLocal) {
        const data = JSON.parse(docsLocal);
        data.forEach((d: DailyDoc) => {
          batch.set(doc(db, `${userPath}/docs`, d.id), d);
        });
        hasData = true;
      }

      // Specials
      const specialsLocal = localStorage.getItem(`fajmuls-specials${suffix}`) || localStorage.getItem('fajmuls-specials');
      if (specialsLocal) {
        const data = JSON.parse(specialsLocal);
        data.forEach((s: SpecialNote) => {
          batch.set(doc(db, `${userPath}/specials`, s.id), s);
        });
        hasData = true;
      }

      if (hasData) {
        await batch.commit().catch(e => console.error("Migration error:", e));
      }
      
      localStorage.setItem(`fajmuls-migrated-${user.uid}`, 'true');
    };

    checkAndMigrate();
  }, [user, loading, notes.length, missedPrayers.length]);

  const addNote = async (note: Note) => {
    if (!user) return;
    const safeNote = Object.fromEntries(Object.entries(note).filter(([_, v]) => v !== undefined));
    try {
      await setDoc(doc(db, `users/${user.uid}/notes`, note.id), safeNote);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/notes/${note.id}`); }
  };
  
  const updateNote = async (updatedNote: Note) => {
    if (!user) return;
    const safeNote = Object.fromEntries(Object.entries({ ...updatedNote, updatedAt: Date.now() }).filter(([_, v]) => v !== undefined));
    try {
      await setDoc(doc(db, `users/${user.uid}/notes`, updatedNote.id), safeNote);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/notes/${updatedNote.id}`); }
  };

  const deleteNote = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, `users/${user.uid}/notes`, id));
    } catch (e) { handleFirestoreError(e, OperationType.DELETE, `users/${user.uid}/notes/${id}`); }
  };
  
  const addFinanceRecord = async (record: FinanceRecord) => {
    if (!user) return;
    const safeRecord = Object.fromEntries(Object.entries(record).filter(([_, v]) => v !== undefined));
    try {
      await setDoc(doc(db, `users/${user.uid}/finance`, record.id), safeRecord);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/finance/${record.id}`); }
  };

  const addFinanceRecordsBulk = async (records: FinanceRecord[]) => {
    if (!user) return;
    const batch = writeBatch(db);
    records.forEach(r => {
      const safeRecord = Object.fromEntries(Object.entries(r).filter(([_, v]) => v !== undefined));
      batch.set(doc(db, `users/${user.uid}/finance`, r.id), safeRecord);
    });
    try {
      await batch.commit();
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/finance`); }
  };

  const updateFinanceRecord = async (record: FinanceRecord) => {
    if (!user) return;
    const safeRecord = Object.fromEntries(Object.entries(record).filter(([_, v]) => v !== undefined));
    try {
      await setDoc(doc(db, `users/${user.uid}/finance`, record.id), safeRecord);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/finance/${record.id}`); }
  };

  const updateFinanceCategoryBulk = async (oldCategory: string, newCategory: string) => {
    if (!user) return;
    const batch = writeBatch(db);
    const recordsToUpdate = financeRecords.filter(r => r.category === oldCategory);
    if (recordsToUpdate.length === 0) return;
    
    recordsToUpdate.forEach(r => {
      const pDoc = doc(db, `users/${user.uid}/finance`, r.id);
      batch.set(pDoc, { ...r, category: newCategory }, { merge: true });
    });
    try {
      await batch.commit();
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/finance/bulkUpdate`); }
  };

  const deleteFinanceCategoryBulk = async (category: string) => {
    if (!user) return;
    const batch = writeBatch(db);
    const recordsToUpdate = financeRecords.filter(r => r.category === category);
    if (recordsToUpdate.length === 0) return;
    
    recordsToUpdate.forEach(r => {
      const pDoc = doc(db, `users/${user.uid}/finance`, r.id);
      batch.set(pDoc, { ...r, category: "" }, { merge: true });
    });
    try {
      await batch.commit();
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/finance/bulkDelete`); }
  };

  const deleteFinanceRecord = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, `users/${user.uid}/finance`, id));
    } catch (e) { handleFirestoreError(e, OperationType.DELETE, `users/${user.uid}/finance/${id}`); }
  };

  const togglePrayer = async (id: string) => {
    if (!user) return;
    const prayer = missedPrayers.find(p => p.id === id);
    if (!prayer) return;
    try {
      await setDoc(doc(db, `users/${user.uid}/prayers`, id), { 
        ...prayer, 
        completed: !prayer.completed, 
        completedAt: !prayer.completed ? Date.now() : null 
      });
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/prayers/${id}`); }
  };

  const addMissedPrayer = async (prayer: MissedPrayer) => {
    if (!user) return;
    const safePrayer = Object.fromEntries(Object.entries(prayer).filter(([_, v]) => v !== undefined));
    try {
      await setDoc(doc(db, `users/${user.uid}/prayers`, prayer.id), safePrayer);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/prayers/${prayer.id}`); }
  };

  const deleteMissedPrayer = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, `users/${user.uid}/prayers`, id));
    } catch (e) { handleFirestoreError(e, OperationType.DELETE, `users/${user.uid}/prayers/${id}`); }
  };

  const deleteAllMissedPrayers = async () => {
    if (!user) return;
    const batch = writeBatch(db);
    missedPrayers.forEach(p => {
      batch.delete(doc(db, `users/${user.uid}/prayers`, p.id));
    });
    try {
      await batch.commit();
    } catch (e) { handleFirestoreError(e, OperationType.DELETE, `users/${user.uid}/prayers`); }
  };

  const addDoc = async (docObj: DailyDoc) => {
    if (!user) return;
    const safeDoc = Object.fromEntries(Object.entries(docObj).filter(([_, v]) => v !== undefined));
    try {
      await setDoc(doc(db, `users/${user.uid}/docs`, docObj.id), safeDoc);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/docs/${docObj.id}`); }
  };

  const addSpecial = async (special: SpecialNote) => {
    if (!user) return;
    const safeSpecial = Object.fromEntries(Object.entries(special).filter(([_, v]) => v !== undefined));
    try {
      await setDoc(doc(db, `users/${user.uid}/specials`, special.id), safeSpecial);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/specials/${special.id}`); }
  };

  const deleteSpecial = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, `users/${user.uid}/specials`, id));
    } catch (e) { handleFirestoreError(e, OperationType.DELETE, `users/${user.uid}/specials/${id}`); }
  };

  const addBudget = async (budget: Budget) => {
    if (!user) return;
    const safeBudget = Object.fromEntries(Object.entries(budget).filter(([_, v]) => v !== undefined));
    try {
      await setDoc(doc(db, `users/${user.uid}/budgets`, budget.id), safeBudget);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/budgets/${budget.id}`); }
  };

  const deleteBudget = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, `users/${user.uid}/budgets`, id));
    } catch (e) { handleFirestoreError(e, OperationType.DELETE, `users/${user.uid}/budgets/${id}`); }
  };

  const addSaving = async (saving: SavingGoal) => {
    if (!user) return;
    const safeSaving = Object.fromEntries(Object.entries(saving).filter(([_, v]) => v !== undefined));
    try {
      await setDoc(doc(db, `users/${user.uid}/savings`, saving.id), safeSaving);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/savings/${saving.id}`); }
  };

  const updateSaving = async (saving: SavingGoal) => {
    if (!user) return;
    const safeSaving = Object.fromEntries(Object.entries(saving).filter(([_, v]) => v !== undefined));
    try {
      await setDoc(doc(db, `users/${user.uid}/savings`, saving.id), safeSaving);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/savings/${saving.id}`); }
  };

  const deleteSaving = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, `users/${user.uid}/savings`, id));
    } catch (e) { handleFirestoreError(e, OperationType.DELETE, `users/${user.uid}/savings/${id}`); }
  };

  const addTrip = async (trip: TripSummary) => {
    if (!user) return;
    try {
      await setDoc(doc(db, `users/${user.uid}/trips`, trip.id), trip);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/trips/${trip.id}`); }
  };

  const updateTrip = async (trip: TripSummary) => {
    if (!user) return;
    try {
      await setDoc(doc(db, `users/${user.uid}/trips`, trip.id), trip);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/trips/${trip.id}`); }
  };

  const deleteTrip = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, `users/${user.uid}/trips`, id));
    } catch (e) { handleFirestoreError(e, OperationType.DELETE, `users/${user.uid}/trips/${id}`); }
  };

  const addTripTemplate = async (template: TripTemplate) => {
    if (!user) return;
    try {
      await setDoc(doc(db, `users/${user.uid}/tripTemplates`, template.id), template);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/tripTemplates/${template.id}`); }
  };

  const deleteTripTemplate = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, `users/${user.uid}/tripTemplates`, id));
    } catch (e) { handleFirestoreError(e, OperationType.DELETE, `users/${user.uid}/tripTemplates/${id}`); }
  };

  const addActivity = async (act: RoutineActivity) => {
    if (!user) return;
    try {
      await setDoc(doc(db, `users/${user.uid}/activities`, act.id), act);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/activities/${act.id}`); }
  };

  const deleteActivity = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, `users/${user.uid}/activities`, id));
      // Also delete completions
      const batch = writeBatch(db);
      completions.filter(c => c.activityId === id).forEach(c => {
         batch.delete(doc(db, `users/${user.uid}/completions`, c.id));
      });
      await batch.commit();
    } catch (e) { handleFirestoreError(e, OperationType.DELETE, `users/${user.uid}/activities/${id}`); }
  };

  const toggleCompletion = async (activityId: string, dateStr: string) => {
    if (!user) return;
    const existing = completions.find(c => c.activityId === activityId && c.dateStr === dateStr);
    try {
      if (existing) {
        await deleteDoc(doc(db, `users/${user.uid}/completions`, existing.id));
      } else {
        const id = (window as any).crypto.randomUUID ? (window as any).crypto.randomUUID() : Math.random().toString(36).substring(2);
        await setDoc(doc(db, `users/${user.uid}/completions`, id), { id, activityId, dateStr });
      }
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/completions`); }
  };

  const updateFinanceMapping = async (group: string, categories: string[]) => {
    if (!user) return;
    const newMappings = { ...financeMappings, [group]: categories };
    try {
      await setDoc(doc(db, `users/${user.uid}/settings`, 'financeMappings'), newMappings);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/settings/financeMappings`); }
  };

  const deleteFinanceMapping = async (group: string) => {
    if (!user) return;
    const newMappings = { ...financeMappings };
    delete newMappings[group];
    try {
      await setDoc(doc(db, `users/${user.uid}/settings`, 'financeMappings'), newMappings);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/settings/financeMappings`); }
  };

  const updateCategoryPref = async (category: string, pref: { iconName: string; color: string }) => {
    if (!user) return;
    const newPrefs = { ...financeCategoryPrefs, [category]: pref };
    try {
      await setDoc(doc(db, `users/${user.uid}/settings`, 'financeCategoryPrefs'), newPrefs);
    } catch (e) { handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/settings/financeCategoryPrefs`); }
  };

  return (
    <AppContext.Provider value={{
      user, notes, financeRecords, missedPrayers, docs, specials, budgets, savings, trips, tripTemplates, 
      activities, completions,
      loading, 
      confirmDialog, alertMessage, financeMappings, financeCategoryPrefs, hideAmounts, setHideAmounts: toggleHideAmounts,
      darkMode, setDarkMode: toggleDarkMode,
      soundEnabled, setSoundEnabled: toggleSoundEnabled,
      setAlert, showConfirm, closeConfirm, updateFinanceMapping, deleteFinanceMapping, updateCategoryPref,
      addNote, updateNote, deleteNote, addTrip, updateTrip, deleteTrip, addTripTemplate, deleteTripTemplate, addFinanceRecord, updateFinanceRecord, updateFinanceCategoryBulk, deleteFinanceCategoryBulk, addFinanceRecordsBulk, deleteFinanceRecord, togglePrayer, addMissedPrayer, deleteMissedPrayer, deleteAllMissedPrayers, addDoc, addSpecial, deleteSpecial,
      addBudget, deleteBudget, addSaving, updateSaving, deleteSaving,
      addActivity, deleteActivity, toggleCompletion
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
}


