export type NoteType = 'normal' | 'ig' | 'personal' | 'workout' | 'daily-goal';

export interface BaseNote {
  id: string;
  type: NoteType;
  createdAt: number;
  updatedAt: number;
}

export interface NormalNote extends BaseNote {
  type: 'normal';
  title: string;
  content: string;
}

export interface IGNote extends BaseNote {
  type: 'ig';
  owner: string;
  songTitle: string;
  content: string;
  backgroundColor: string;
  history: string[]; // Keep track of past contents
}

export interface PersonalNote extends BaseNote {
  type: 'personal';
  personName?: string;
  extraNotes: string;
  customFields: { key: string; value: string }[];
  // Legacy fields for backward compatibility
  nik?: string;
  ssn?: string;
  postalCode?: string;
  address?: string;
  email?: string;
  accountNumber?: string;
}

export interface WorkoutDetail {
  id: string;
  exercise: string;
  sets: number;
  reps: number;
  weight?: string;
  note?: string;
}

export interface WorkoutNote extends BaseNote {
  type: 'workout';
  title: string;
  routine: string;
  durationMins: number;
  workoutCategory?: string;
  details?: WorkoutDetail[];
}

export interface DailyGoalItem {
  id: string;
  text: string;
  category: string;
  completed: boolean;
}

export interface DailyGoalNote extends BaseNote {
  type: 'daily-goal';
  dateStr: string;
  goals: DailyGoalItem[];
}

export type Note = NormalNote | IGNote | PersonalNote | WorkoutNote | DailyGoalNote;

export interface FinanceRecord {
  id: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  parentCategory?: string; // This will now be derived from mappings
  note: string;
  createdAt: number;
  iconName?: string;
  isDetailed?: boolean; // New: mark for detailed records
  recurring?: {
    frequency: 'daily' | 'weekly' | 'monthly' | 'yearly';
    nextDate: number;
  };
}

export interface Budget {
  id: string;
  category: string;
  amount: number;
  period: 'weekly' | 'monthly' | 'yearly';
  createdAt: number;
}

export interface SavingGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  location: string; // e.g., 'Bank', 'Cash', 'Investment'
  deadline?: string; // e.g., '2025-12-31'
  createdAt: number;
}

export interface BalanceSheet {
  cash: number;
  bank: number;
  investment: number;
}

export interface FinanceMapping {
  [groupName: string]: string[]; 
}

export type Fardhu = 'Subuh' | 'Dzuhur' | 'Ashar' | 'Maghrib' | 'Isya' | 'Belum Diketahui';

export interface MissedPrayer {
  id: string;
  prayer: Fardhu;
  dateInfo: string;
  completed: boolean;
  completedAt?: number;
}

export interface DailyDoc {
  id: string;
  url: string;
  name: string;
  createdAt: number;
}

export interface SpecialNote {
  id: string;
  dayTitle: string;
  content: string;
  createdAt: number;
}

export interface TripLocation {
  city: string;
  detail: string;
}

export interface TripSummary {
  id: string;
  origin: TripLocation;
  destination: TripLocation;
  vehicle: string;
  status: 'ongoing' | 'completed';
  startTime: number;
  endTime?: number;
  createdAt: number;
  tollCost?: number;
  fuelCost?: number;
  conditions?: string[];
  receipts?: { id: string; url: string; name: string }[];
}

export interface TripTemplate {
  id: string;
  origin: TripLocation;
  destination: TripLocation;
  vehicle: string;
}

export interface RoutineActivity {
  id: string;
  name: string;
  createdAt: number;
}

export interface RoutineCompletion {
  id: string;
  activityId: string;
  dateStr: string; // YYYY-MM-DD
}
